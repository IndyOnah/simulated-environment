#All the required imports
import numpy as np
import torch
import scipy
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn import datasets, linear_model
import tensorflow as tf

print("All necessary imports are imported.")
